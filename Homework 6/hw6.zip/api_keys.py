# OpenWeatherMap API Key
api_key = "43d89f2ccc0f5db20dc88ef2c6d8ff2a"

